#include "../include/network_util.h"
#include "../include/control_handler.h"
#include "../include/connection_manager.h"
#include "../include/global.h"
#include "../include/control_header_lib.h"

#ifndef AUTHOR_H_
#define AUTHOR_H_

void author_response(int sock_index);

#endif

